
import { List } from 'antd-mobile';
import { Link } from 'react-router-dom';

export default class UserGuestChatPage extends Component {

  componentWillReceiveProps(nP) {
    
  }

  componentDidMount() {
    
  }

  loginOut = () => {
    this.props.history.replace('/login');
  }


  render() {

    return (
      <div>
          
      </div>
    )
  }
}
