
export {store} from './configureStore';
