import {
    combineReducers
} from 'redux';
import { default as homeData } from '../pages/admin/physical/homeRedux';

export default combineReducers({
    homeData
});